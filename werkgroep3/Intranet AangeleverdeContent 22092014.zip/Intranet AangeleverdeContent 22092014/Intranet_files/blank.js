function ULSaew(){var o=new Object;o.ULSTeamName="Microsoft SharePoint Foundation";o.ULSFileName="blank.js";return o;}
